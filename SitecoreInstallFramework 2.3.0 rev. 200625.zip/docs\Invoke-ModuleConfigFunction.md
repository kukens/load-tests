---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-ModuleConfigFunction

## SYNOPSIS
Determines if a module is present on the current system.

## SYNTAX

```
Invoke-ModuleConfigFunction [-Name] <String> [-Version] [<CommonParameters>]
```

## DESCRIPTION
Determines if a module is present on the current system, alternatively will also
return the version of the installed module.

## EXAMPLES

### Example 1
```powershell
PS C:\> Invoke-ModuleConfigFunction -Name SQLServer
```

Determines if the module `SQLServer` is installed.

### Example 2
```powershell
PS C:\> Invoke-ModuleConfigFunction -Name SQLServer -Version
```

Returns the version of the `SQLServer` module.

## PARAMETERS

### -Name
The Name of the module to be searched for.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Version
Return the version of the module rather than the installation status.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
