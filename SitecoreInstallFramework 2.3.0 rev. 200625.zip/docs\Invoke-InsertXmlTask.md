---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-InsertXmlTask

## SYNOPSIS
Inserts a new sub-document into an XML document in a file, appended as a child to one or many parents.

## SYNTAX

```
Invoke-InsertXmlTask [-FilePath] <String> [-XPath] <String> [-Xml] <XmlDocument> [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION
Inserts a new sub-document into an XML document in a file, using a given XPath to specify one or many parents.  The parent(s) must be XML Elements.  If many parents are selected, the new sub-document is duplicated for each parent.

## EXAMPLES

### Example 1
```
PS C:\> Invoke-InsertXmlTask -FilePath c:\example.xml -XPath //root/config -Xml "<subroot><child attr=""attrvalue"">avalue</child></subroot>"
```

Inserts the 'subroot' document as a child of the 'config' element.

### Example 2
```
PS C:\> Invoke-InsertXmlTask -FilePath c:\example.xml -XPath //root/config/* -Xml "<subroot><child attr=""attrvalue"">avalue</child></subroot>"
```

Inserts a copy of the 'subroot' document as a child of each child of the 'config' element.

## PARAMETERS

### -FilePath
The path to an XML document.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Xml
The XML document to insert as a child of the elements selected by the given XPath.

```yaml
Type: XmlDocument
Parameter Sets: (All)
Aliases:

Required: True
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -XPath
The XPath to locate parents in the XML document, for which the new XML will be appended to as a child.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
