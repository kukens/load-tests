---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-WindowsFeatureConfigFunction

## SYNOPSIS
Returns if a Windows Feature is enabled or not.

## SYNTAX

```
Invoke-WindowsFeatureConfigFunction [-Name] <String> [<CommonParameters>]
```

## DESCRIPTION
Returns if a Windows Feature is enabled or not.

## EXAMPLES

### Example 1
```powershell
PS C:\> Invoke-WindowsFeatureConfigFunction -Name "IIS-WebServer"
```

Determine if the feature "IIS-Webserver" is enabled or not and returns true or false.

## PARAMETERS

### -Name
The feature to check. 

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
