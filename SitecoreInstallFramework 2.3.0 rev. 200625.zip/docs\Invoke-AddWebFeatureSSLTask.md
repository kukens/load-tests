---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-AddWebFeatureSSLTask

## SYNOPSIS
Creates and binds a certificate chain to a website.

## SYNTAX

```
Invoke-AddWebFeatureSSLTask [-HostName] <String> [-SiteName <String>] [-Port <Int32>]
 [-ClientCertLocation <StoreLocation>] [-OutputDirectory <String>] [-RootDnsName <String>]
 [-RootCertName <String>] [-RootCertLocation <StoreLocation>] [-Password <SecureString>] [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION
Creates/searches for a root certification authority and client web certificate as required and
assigns it to a website.

## EXAMPLES

### Example 1
```powershell
PS C:\> Invoke-AddWebFeatureSSLTask -Hostname test.com
```

Attempts to locate a certificate chain for `test.com` and if one is not found then
a root authority will be created and a subordinate web certificate created. The
web certificate will then be assigned to `test.com`

## PARAMETERS

### -ClientCertLocation
The location to create/search for the client certificate. Defaults to LocalMachine.

```yaml
Type: StoreLocation
Parameter Sets: (All)
Aliases:
Accepted values: LocalMachine, CurrentUser

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -HostName
The hostname of the website the certificate is to be bound to.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -OutputDirectory
Directory the certificates will be exported to.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Password
A SecureString object of the password the certificates should be exported with.

```yaml
Type: SecureString
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Port
The port that the website should be bound to.

```yaml
Type: Int32
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -RootCertLocation
The location to create/search for the root certificate. Defaults to LocalMachine.

```yaml
Type: StoreLocation
Parameter Sets: (All)
Aliases:
Accepted values: LocalMachine, CurrentUser

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -RootCertName
The name of the root certificate authority to be created.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -RootDnsName
The DNS name of the root certification authority to be searched for/created.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SiteName
The name of the website the certificate is to be bound to.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
