---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-ValidateCountConfigFunction

## SYNOPSIS
Validates that the parameter array count is in the specified range.

## SYNTAX

```
Invoke-ValidateCountConfigFunction [[-MinLength] <Int32>] [[-MaxLength] <Int32>] [-Param] <PSObject>
 [<CommonParameters>]
```

## DESCRIPTION
Returns `$true` if the parameter parameter length is in the specified range, `$false` otherwise.

## EXAMPLES

### Example 1
```powershell
PS C:\> Invoke-ValidateCountConfigFunction -MinLength 2 -MaxLength 4 -Param @(1, 2, 3)
PS C:\> $true
```

The parameter array has length of 3, which is in the range of 2 to 4, so result is `$true`.

### Example 2
```powershell
PS C:\> Invoke-ValidateCountConfigFunction -MinLength 2 -MaxLength  4 -Param @(1, 2, 3, 4, 5)
PS C:\> $false
```

The parameter array has length of 5, which isn't in the range of 2 to 4, so result is `$false`.

## PARAMETERS

### -MaxLength
The maximum length of parameter.

```yaml
Type: Int32
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -MinLength
The minimum length of parameter.

```yaml
Type: Int32
Parameter Sets: (All)
Aliases:

Required: False
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Param
The parameter to validate.

```yaml
Type: PSObject
Parameter Sets: (All)
Aliases:

Required: True
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
