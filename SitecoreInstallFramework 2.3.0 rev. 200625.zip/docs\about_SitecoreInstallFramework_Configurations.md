﻿# SitecoreInstallFramework_Configurations
## about_SitecoreInstallFramework_Configurations

# SHORT DESCRIPTION
Full configuration examples for the Sitecore Install Framework.

# LONG DESCRIPTION
This topic outlines examples of configurations that can be created using the
Sitecore Install Framework.

See `about_SitecoreInstallFramework` for general information on the framework
and `about_SitecoreInstallFramework_Extending` for information on creating your
own tasks and config functions to use in a configuration.

# EXAMPLES

## Single Task
```
{
    "Tasks": {
        "CopyFiles": {
            "Type": "Copy",
            "Params": {
                "Source": "c:\myfiles",
                "Destination": "c:\destination"
            }
        }
    }
}
```
This example will copy files from `c:\myfiles` to `c:\destination`

## Skipping a Task
```
{
    "Tasks": {
        "CopyFiles": {
            "Type": "Copy",
            "Params": {
                "Source": "c:\myfiles",
                "Destination": "c:\destination"
            },
            "Skip": "true"
        }
    }
}
```
This example will skip the "CopyFiles" task.

## Default Parameters
```
{
    "Parameters": {
        "Source": { "Type": "string", "DefaultValue": "c:\myfiles" }
    },
    "Tasks": {
        "CopyFiles": {
            "Type": "Copy",
            "Params": {
                "Source": "[parameter('Source')]",
                "Destination": "c:\destination"
            }
        }
    }
}
```
This example will copy files from `c:\myfiles` to `c:\destination` by default.
If the `Source` parameter is passed, a different set of files will be copied.

For example, if the above was saved as `configuration.json`, running
`Install-SitecoreConfiguration -Path .\configuration.json -Source c:\otherfiles` would
copy files from `c:\otherfiles` to the destination.

## Mandatory Parameters
```
{
    "Parameters": {
        "Source": { "Type": "string", "Description" : "Path to the source files" }
    },
    "Tasks": {
        "CopyFiles": {
            "Type": "Copy",
            "Params": {
                "Source": "[parameter('Source')]",
                "Destination": "c:\destination"
            }
        }
    }
}
```
In this example the `Source` parameter is now mandatory. Running `Install-SitecoreConfiguration`
using this configuration will request the value if the user does not provide it.
The description can be shown at the command line to help the user understand what
the parameter requires.

## Reference Parameters
```
{
    "Parameters": {
        "Source": { "Type": "string", "DefaultValue": "c:\myfiles" },
        "Reference": { "Type": "string", "Reference": "Source" }
    },
    "Tasks": {
        "CopyFiles": {
            "Type": "Copy",
            "Params": {
                "Source": "[parameter('Reference')]",
                "Destination": "c:\destination"
            }
        }
    }
}
```
This example will copy files from `c:\myfiles` to `c:\destination` by default.
If the `Source` parameter is passed, a different set of files will be copied.

For example, if the above was saved as `configuration.json`, running
`Install-SitecoreConfiguration -Path .\configuration.json -Source c:\otherfiles` would
copy files from `c:\otherfiles` to the destination.

## Parameters validation
```
{
    "Parameters": {
        "Source": {
            "Type": "string",
            "DefaultValue": "c:\myfiles",
            "Validate": "[validatelength(3, 260, $_)]"
        },
    },
    "Tasks": {
        "CopyFiles": {
            "Type": "Copy",
            "Params": {
                "Source": "[parameter('Source')]",
                "Destination": "c:\destination"
            }
        }
    }
}
```
In this example the `Source` parameter will be validated against the config function `validatelength` checking that the string in between 3 and 260 characters long. If user sets invalid value for `Source` parameter (e.g. `C:`), `Install-SitecoreConfiguration` command will be aborted.

## Variables
```
{
    "Parameters": {
        "Source": { "Type": "string", "Description" : "Path to the source files" }
    },
    "Variables": {
        "Destination": "[concat(environment('SystemDrive'), '\\destination')]"
    },
    "Tasks": {
        "CopyFiles": {
            "Type": "Copy",
            "Params": {
                "Source": "[parameter('Source')]",
                "Destination": "[variable('Destination')]"
            }
        }
    }
}
```
In this example, a variable is used to calculate the destination path. Variables
can use other config functions (e.g. Parameter, Environment, Concat) and also
use variables that have already been declared.

## Multiple Tasks
```
{
    "Parameters": {
        "Source": { "Type": "string", "Description" : "Path to the source files" }
    },
    "Variables": {
        "Destination": "[concat(environment('SystemDrive'), '\\destination')]"
    },
    "Tasks": {
        "PreparePath": {
            "Type": "EnsurePath",
            "Params": {
                "Clean": [ "[variable('Destination')]" ]
            }
        },
        "CopyFiles": {
            "Type": "Copy",
            "Params": {
                "Source": "[parameter('Source')]",
                "Destination": "[variable('Destination')]"
            }
        }
    }
}
```
In this example the task called `PreparePath` will run first. Using the `EnsurePath`
task will ensure the destination path exists and does not contain any files.
The `CopyFiles` task copies files to the empty directory.

By default, tasks are ran in the order they are declared in the configuration.
The order of the tasks can be modified using the `From`, `To`, and `Tasks`
parameters when calling `Install-SitecoreConfiguration`.

## Uninstall Tasks

Configurations may optionally contain an `UninstallTasks` section. This section takes
the same form as the `Tasks` section. It should contain a list of tasks that will
back out all the actions completed in the `Tasks` section.

Uninstall tasks are invoked either by passing the `-Uninstall` switch to `Install-SitecoreConfiguration`
or by calling the alias `Uninstall-SitecoreConfiguration`. It is not necessary to
include the `-Uninstall` switch if calling `Uninstall-SitecoreConfiguration`

```
{
    "Parameters" :{
        "SolrService": {
            "Type": "string",
            "DefaultValue": "Solr-7.2.1",
            "Description": "The name of the Solr service."
        },
    },
    "UninstallTasks": {
        "RemoveSolrService": {
            "Type": "RemoveService",
            "Params": {
                "Name": "[parameter('SolrService')]"
            }
        },
    }
}
```
In this example the uninstall task `RemoveSolrService` will execute the `RemoveService`
task and stop and remove the service specified in the `SolrService` parameter.

If you have referenced other configurations via the Includes section, each of the
included configurations Uninstall Tasks are run, in reverse order, after tasks
in the first configuration.

## Named Parameters

Named parameters are a comma separated list denoted by following the parameter name
with a colon:

```
{
    "Variables": {
        "Variable1": "[GetFunction(Number:1234,String:'Text',Switch:True)]"
    },
}
```
In this example `Variable1` will call the function `GetFunction` and pass it the named
parameter `Number` with the value 1234, the named parameter `string` with the value
'Text' and the switch parameter `Switch` with the value `true`. It is the equivalent of typing
`Get-Function -Number:1234 -String:"Text" -Switch:$True` on the command line.

Nested functions are also permitted and may refer to parameters, variables
or other config functions.

## Extending with modules
You can extend configurations with custom task and config functions. You can use
the `Register-SitecoreInstallExtension` command to register functions for use in
configurations :
```
Register-SitecoreInstallExtension -Command Write-Output -As WriteOutput -Type Task
Register-SitecoreInstallExtension -Command Get-Random -As Random -Type ConfigFunction
```

If the customizations were saved to `c:\scripts\extensions.psm1`, they can be
included in a configuration by setting the `Modules` property:

```
{
    "Parameters": {
        "Source": { "Type": "string", "Description" : "Path to the source files" }
    },
    "Variables": {
        "RandomFolder": "[random(5000)]",
        "Destination": "[concat(environment('SystemDrive'), '\\', variable('RandomFolder'))]"
    },
    "Tasks": {
        "CustomWrite": {
            "Type": "WriteOutput",
            "Params": {
                "Message": "Custom task is running"
            }
        },
        "PreparePath": {
            "Type": "EnsurePath",
            "Params": {
                "Clean": [ "[variable('Destination')]" ]
            }
        },
        "CopyFiles": {
            "Type": "Copy",
            "Params": {
                "Source": "[parameter('Source')]",
                "Destination": "[variable('Destination')]"
            }
        }
    },
    "Modules": [
        "c:\\scripts\\extensions.psm1"
    ]
}
```

Now when the configuration is ran the variable `RandomFolder` is set using the
custom config function. The `CustomWrite` task is also ran using the custom
PowerShell function.

Multiple modules can be added to a configuration.

## Settings
You can control features of the installation process by adding settings to a
configuration.

```
{
    "Settings": {
        "RequireAdmin" : false,
        "ErrorAction" : "Stop",
        "WarningAction": "Continue"
        "InformationAction": "Continue"
    }
}
```

For more information on settings see `about_SitecoreInstallFramework_Settings`

# SEE ALSO

- about_SitecoreInstallFramework
- about_SitecoreInstallFramework_Extending
- about_SitecoreInstallFramework_Settings
