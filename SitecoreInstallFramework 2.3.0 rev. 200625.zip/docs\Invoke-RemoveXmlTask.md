---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-RemoveXmlTask

## SYNOPSIS
Removes one or more nodes from an XML document in a file specified by an XPath.

## SYNTAX

```
Invoke-RemoveXmlTask [-FilePath] <String> [-XPath] <String> [-IgnoreNoMatches] [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION
Removes one or more nodes from an XML document in a file, using a given XPath to specify the nodes for deletion.

## EXAMPLES

### Example 1
```
PS C:\> Invoke-RemoveXmlTask -FilePath c:\example.xml -XPath //root/config
```

Removes the 'config' element from the XML document in the file.

### Example 2
```
PS C:\> Invoke-RemoveXmlTask -FilePath c:\example.xml -XPath //root/config/*
```

Removes all the child elements of the 'config' element from the XML document in the file.

### Example 3
```
PS C:\> Invoke-RemoveXmlTask -FilePath c:\example.xml -XPath //root/config/@name
```

Removes the 'name' attribute from the 'config' element in the XML document in the file.

## PARAMETERS

### -FilePath
The path to an XML document.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -IgnoreNoMatches
{{Fill IgnoreNoMatches Description}}

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -XPath
The XPath that selects which nodes to remove from the XML document.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
