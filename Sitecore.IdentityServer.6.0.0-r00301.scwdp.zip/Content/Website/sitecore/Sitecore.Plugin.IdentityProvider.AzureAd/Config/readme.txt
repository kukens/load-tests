﻿1. To enable Azure AD provider set the following setting to true Settings:Sitecore:ExternalIdentityProviders:IdentityProviders:AzureAd:Enabled.
2. Fill in ClientId, TenantId in the config.
3. Optional: add transformation rules to the ClaimsTransformations node.
