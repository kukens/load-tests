---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-NewSignedCertificateTask

## SYNOPSIS
Creates an SSL certificate for web hosting.

## SYNTAX

```
Invoke-NewSignedCertificateTask [-Signer] <X509Certificate2> [[-CertStoreLocation] <String>]
 [[-DnsName] <String[]>] [[-FriendlyName] <String>] [[-Path] <String>] [[-Name] <String>] [-IncludePrivateKey]
 [[-Password] <SecureString>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
Creates an SSL certificate for web hosting signed by the specified authority.
The signing authority must be in the Root certificate store.

## EXAMPLES

### Example 1
```powershell
PS C:\> $Signer = (Invoke-GetCertificateConfigFunction -ID 1234567890ABCDEF00001234567890ABCDEF0000 )
PS C:\> Invoke-NewSignedCertificateTask -Signer $Signer
```

Creates a web hosting certificate signed by the `$Signer` root authority.

### Example 2
```powershell
PS C:\> $Signer = (Invoke-GetCertificateConfigFunction -ID 1234567890ABCDEF00001234567890ABCDEF0000 )
PS C:\> Invoke-NewSignedCertificateTask -Signer $Signer -DNSName "website.com","example.com","127.0.0.1"
```

Creates a web hosting certificate signed by the `$Signer` root authority with the
Common Name set to `website.com` and also including `example.com` and `127.0.0.1`
as Subject Alternative Names.

## PARAMETERS

### -CertStoreLocation
The location that the certificate will be created in. Defaults to
Cert:\LocalMachine\My

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -DnsName
A list of DNS names to be included in the certificate. The first item will be the
issuer Common Name (CN). All items will be included as Subject Alternative Names.

```yaml
Type: String[]
Parameter Sets: (All)
Aliases:

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -FriendlyName
The friendly name for the certificate.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -IncludePrivateKey
If required the private key will be included in the file. Certificates with private
keys are exported as a PFX file.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Name
The filename for the exported certificate.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 5
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Password
A Secure String object to use as a password for the exported certificate.

```yaml
Type: SecureString
Parameter Sets: (All)
Aliases:

Required: False
Position: 6
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Path
If supplied the certificate will be exported to this location.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 4
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Signer
An X509 Certificate object that is a valid Certificate Authority. This certificate
must have a private key associated with it.

```yaml
Type: X509Certificate2
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
