---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-HostHeaderTask

## SYNOPSIS
Performs the action over the entry in the system hosts file.

## SYNTAX

```
Invoke-HostHeaderTask [-Hostname] <String> [[-IPAddress] <String>] [[-Action] <String>] [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION
Checks the hosts file for the entry to perform the action over. Adds the entry if it does not exist or removes the entry if it exists depending on given action.

A backup of the current hosts file is taken before updating.

## EXAMPLES

### EXAMPLE 1
```
PS C:\> Invoke-HostHeaderTask -Hostname customhost
```

This will add a new host entry of '127.0.0.1 customhost' to the hosts file.

### EXAMPLE 2
```
PS C:\> Invoke-HostHeaderTask -Hostname customhost -IPAddress 192.168.0.5
```

This will add a new host entry of '192.168.0.5 customhost' to the hosts file.

### EXAMPLE 3
```
PS C:\> Invoke-HostHeaderTask -Hostname customhost -IPAddress 192.168.0.5 -Action "Remove"
```

This will remove host entry of '192.168.0.5 customhost' from the hosts file.

## PARAMETERS

### -Action
Specifies an action to perform over given host file entry.

```yaml
Type: String
Parameter Sets: (All)
Aliases:
Accepted values: Add, Remove

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Hostname
The hostname to perform action over.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -IPAddress
The IP Address of the host.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: 127.0.0.1
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs. The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS
