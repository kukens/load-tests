---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-InstallPSModuleTask

## SYNOPSIS
Installs PowerShell module on a remote server.

## SYNTAX

```
Invoke-InstallPSModuleTask [-ModuleName] <String[]> [[-ModuleRequiredVersion] <Version>]
 [-RepositoryName] <String> [-RepositorySource] <Uri> [-ToSession] <PSSession> [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION
Registers PowerShell repository and installs PowerShell module on a remote server.

## EXAMPLES

### Example 1
```powershell
PS C:\> Invoke-InstallPSModuleTask -ModuleName "Module1" -RepositoryName "Repository1" -RepositorySource "https://repository1" -ToSession $remoteSession
```

This will register 'https://repository1' PowerShell repository source as 'Repository1' and install 'Module1' PowerShell module on the remote server represented by '$remoteSession' session.

## PARAMETERS

### -ModuleName
Specifies a name of PowerShell module to install.

```yaml
Type: String[]
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ModuleRequiredVersion
Specifies a version of PowerShell module to install.

```yaml
Type: Version
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -RepositoryName
Specifies a name of PowerShell repository to register.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -RepositorySource
Specifies a source of PowerShell repository to register.

```yaml
Type: Uri
Parameter Sets: (All)
Aliases:

Required: True
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ToSession
Specifies target remote server to install PowerShell module on.

```yaml
Type: PSSession
Parameter Sets: (All)
Aliases:

Required: True
Position: 4
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
