---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-InstallSitecoreConfigurationTask

## SYNOPSIS
Installs Sitecore configuration to the remote server.

## SYNTAX

```
Invoke-InstallSitecoreConfigurationTask [-ConfigurationParameters] <Hashtable> [-Session] <PSSession> [-WhatIf]
 [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
Installs Sitecore configuration represented by a list of parameters to the remote server represented by session object.

## EXAMPLES

### Example 1
```powershell
PS C:\> Invoke-InstallSitecoreConfigurationTask -ConfigurationParameters $configParameters -Session $remoteSession
```

This will install Sitecore configuration represented by '$configParameters' parameters to the remote server represented by $remoteSession session.

## PARAMETERS

### -ConfigurationParameters
Specifies parameters of Sitecore configuration to install.

```yaml
Type: Hashtable
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Session
Specifies target remote server to install Sitecore configuration to.

```yaml
Type: PSSession
Parameter Sets: (All)
Aliases:

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
