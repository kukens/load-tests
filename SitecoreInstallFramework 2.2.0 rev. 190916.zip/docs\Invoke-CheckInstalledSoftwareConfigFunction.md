---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-CheckInstalledSoftwareConfigFunction

## SYNOPSIS
Determines if a program has been installed.

## SYNTAX

```
Invoke-CheckInstalledSoftwareConfigFunction [-Name] <String> [-Version] [<CommonParameters>]
```

## DESCRIPTION
Determines if a program has been installed from a list of the programs available for uninstallation.

## EXAMPLES

### Example 1
```powershell
PS C:\> Invoke-CheckInstalledSoftwareConfigFunction -Name "Test Software"
```

Determine if a program called `Test Software` is installed.

### Example 2
```powershell
PS C:\> Invoke-CheckInstalledSoftwareConfigFunction -Name "Test Software" -Version
```

Determine if a program called `Test Software` is installed and if so return the version.

## PARAMETERS

### -Name
The name of the software to search for.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Version
Return the version of the installed software.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
