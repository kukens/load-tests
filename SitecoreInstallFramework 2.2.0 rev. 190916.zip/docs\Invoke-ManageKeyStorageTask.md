---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-ManageKeyStorageTask

## SYNOPSIS
Manages user key storage in HKLM registry. Required when keys cannot be stored in user profile.

## SYNTAX

```
Invoke-ManageKeyStorageTask [-AppPoolName] <String> [-Action] <String> [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION
Provisions the HKLM registry so that the specified user account can persist auto-generated machine keys.

## EXAMPLES

### Example 1
```powershell
PS C:\> Invoke-ManageKeyStorageTask -AppPoolName "MvcClient" -Action "Create"
```

Creates key storage for `Mvclient` application pool account. The example path to key storage after running the command:
`Computer\HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\ASP.NET\4.0.30319.0\AutoGenKeys\S-1-5-82-1731550076-428533086-1153257930-2037551521-321001858`

### Example 2
```powershell
PS C:\> Invoke-ManageKeyStorageTask -AppPoolName "MvcClient" -Action "Delete"
```

Deletes key storage for `Mvclient` application pool account.

## PARAMETERS

### -Action
Action which will be applied to storage: Create, Delete.

```yaml
Type: String
Parameter Sets: (All)
Aliases:
Accepted values: create, delete

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -AppPoolName
Application pool name.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
